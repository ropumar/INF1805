qualquer no pode pedir a localizacao do outro se ele tiver voltagem modificada. 
Ele escolhe o no por meio do photo. Ele diz quais led acender por meio do segundo digito da temp.
Ele acende o primeiro led da rota mais curta, para que o usuario possa ver que ele chegou ao no
usando a rota calculada anterioremente.
